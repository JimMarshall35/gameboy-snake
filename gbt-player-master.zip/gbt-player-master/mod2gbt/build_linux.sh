#!/bin/bash
gcc -o mod2gbt mod2gbt.c

